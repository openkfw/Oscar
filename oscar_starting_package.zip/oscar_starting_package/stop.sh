#!/bin/bash
set -e
docker compose down --remove-orphans
echo "Oscar application stopped."
