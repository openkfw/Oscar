#!/bin/bash
set -e
docker compose down --remove-orphans && docker compose up api-service oscar-db-service mongo-express azurite  -d
docker compose up frontend -d
docker compose up initial-data-load-service -d
echo "Oscar application is running, please open localhost in web browser."
