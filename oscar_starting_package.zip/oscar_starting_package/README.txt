OSCAR PLATFORM Start package

Oscar application is web based application not meant to run locally on your
computer, but you can start and test it with this package.

Before you can start:
You need to download and start Docker https://docs.docker.com/get-docker/ 
to simulate cloud, where it normally runs.
Next, you need empty localhost. To check this, open your web browser,
write "localhost" in the address bar and press Enter. It should show you that web page is
not found (as when you are not connected to the Internet).
If you have no to little experience with running scripts with command line,
move the oscar_starting_package folder to your Desktop.

If you want to enable Azure Maps and Search functionality:
These functionalities are connecting to Microsoft Azure services 
(https://docs.microsoft.com/en-us/azure/azure-maps/about-azure-maps), 
where you need to create account (https://azure.microsoft.com/en-gb/services/azure-maps/)
and get connection string (https://docs.microsoft.com/en-us/azure/azure-maps/azure-maps-authentication#shared-key-authentication).
This key needs to be saved in .env file in this folder as AZURE_MAPS_CONNECTION_STRING=yourOwnConnectionString
(If you can't see .env file in the folder, you need first to enable displaying of invisible files)

How to start application:
1. Open command line
On Mac: open Terminal.app
On Windows: write "cmd" in search and press enter
2. Copy this text on command line (or run the start script from your destination
if you are experienced and you have saved this folder somewhere else).
On Mac: "cd Desktop/oscar_starting_package && sh ./start.sh"
On Windows:
3. Wait until you can see "Oscar application is running, please open
localhost in web browser." on command line.
4. Open web browser (We recommend Google Chrome or Mozilla Firefox,
Internet Explorer is not supported and other browsers were not tested).
5. Write "localhost" in address bar and press Enter.
6. Oscar application opens directly in browser.
7. Close application with following text on command line:
On Mac: "sh ./stop.sh"
On Windows:
8. Wait until you can see "Oscar application stopped." on command line.
9. Close command line.
